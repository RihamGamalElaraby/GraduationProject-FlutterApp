abstract class ComfyviewState {}

class initialState extends ComfyviewState {}

class SucssesChangeBottimnavState extends ComfyviewState {}
