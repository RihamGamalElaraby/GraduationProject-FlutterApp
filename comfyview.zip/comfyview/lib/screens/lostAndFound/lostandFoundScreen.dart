import 'package:comfyview/screens/lostAndFound/cubit/LostAndFoundcubit.dart';
import 'package:comfyview/screens/lostAndFound/cubit/lostAndFoundStates.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class LostAndFound extends StatelessWidget {
  LostAndFound({super.key});

  final searchController = TextEditingController();

  void _onSearchButtonPressed(BuildContext context) {
    LostAndFoundCubit.get(context)
        .LocationBack(searchValue: searchController.text);
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<LostAndFoundCubit, LostAndFoundStates>(
      listener: (context, state) {},
      builder: (context, state) {
        return Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Lost and Found',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: searchController,
                keyboardType: TextInputType.text,
                decoration: InputDecoration(
                  labelText: 'Search',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: const BorderSide(color: Colors.blue),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: const EdgeInsets.symmetric(vertical: 15.0),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide(color: Colors.blue.withOpacity(0.5)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide(color: Colors.blue),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => _onSearchButtonPressed(context),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  // primary: Colors.blue,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                child: const Center(
                  child: Text(
                    'Search',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Divider(
                thickness: 1,
                color: Colors.black,
              ),
              const SizedBox(height: 20),
              const Text(
                'Results',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              Expanded(
                child: state is LoadingStatesLost
                    ? Center(child: CircularProgressIndicator())
                    : state is FailStatesLost
                        ? Center(
                            child: Text(
                              'No results found or an error occurred.',
                              style: TextStyle(color: Colors.red, fontSize: 16),
                            ),
                          )
                        : ListView.separated(
                            itemBuilder: (context, index) => Card(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                              ),
                              elevation: 4,
                              margin: const EdgeInsets.symmetric(vertical: 10),
                              child: ListTile(
                                onTap: () {
                                  // Handle onTap
                                },
                                contentPadding: const EdgeInsets.all(20.0),
                                title: Row(
                                  children: [
                                    const Text(
                                      'Location: ',
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Expanded(
                                      child: Text(
                                        LostAndFoundCubit.get(context)
                                                .location ??
                                            'no location',
                                        style: const TextStyle(
                                          fontSize: 16,
                                          color: Colors.blue,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                                trailing: IconButton(
                                  onPressed: () {
                                    // Handle Google Maps
                                  },
                                  icon: const Icon(Icons.gps_fixed),
                                ),
                              ),
                            ),
                            separatorBuilder: (context, index) =>
                                const SizedBox(),
                            itemCount: 1,
                          ),
              ),
            ],
          ),
        );
      },
    );
  }
}
