abstract class LostAndFoundStates {}

class InitialStateLost extends LostAndFoundStates {}

class LoadingStatesLost extends LostAndFoundStates {}

class SucssesStatesLost extends LostAndFoundStates {}

class FailStatesLost extends LostAndFoundStates {}
