const APIPATH = 'https://graduationproject-backend.onrender.com/api/';

const SIGNUP = 'signUp';
const SIGNIN = 'signIn';
