package com.example.comfyview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
